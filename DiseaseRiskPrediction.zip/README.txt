Early Stage Diabetes Risk Prediction
This project predicts the risk of early stage diabetes using a Random Forest classifier.

Dataset
The dataset used in this project can be found on Kaggle: [Early Stage Diabetes Risk Prediction Dataset](https://www.kaggle.com/datasets/singhakash/early-stage-diabetes-risk-prediction-datasets/data?select=diabetes_data_upload.csv)

Duha Demiroğlu

License
This project is licensed under the MIT License.

